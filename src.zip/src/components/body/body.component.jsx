import React from "react";

const Body = (props) => {
  return <div>{props.children}</div>;
};

export default Body;
